$(function () {
    //加载弹出层
    layui.use(['form','element'],
    function() {
        layer = layui.layer;
        element = layui.element;
    });

    //触发事件
  var tab = {
        tabAdd: function(title,url,id){
          //新增一个Tab项
          element.tabAdd('xbs_tab', {
            title: title 
            ,content: '<iframe tab-id="'+id+'" frameborder="0" src="'+url+'" scrolling="auto" class="x-iframe"></iframe>'
            ,id: id
          })
        }
        ,tabDelete: function(othis){
           element.tabDelete('xbs_tab',othis);
        }
        ,tabChange: function(id){
          //切换到指定Tab项
          element.tabChange('xbs_tab', id); //切换到：用户管理
        }
        ,closeother: function() {  
            $('.layui-tab-title li').each(function(i,el){
              var id = $(el).attr('lay-id');
              if(!$(this).hasClass('layui-this') && id!=''){
                element.tabDelete('xbs_tab', id);
              }
               
            });
          
        }
        ,closeall: function(t) {  
             $('.layui-tab-title li').each(function(){
                var id = parseInt($(this).attr('lay-id'));
                if(id>0){
                    element.tabDelete('xbs_tab', id);
                }

             })
             $('.layui-tab-title li').eq(0).addClass('layui-this');            
          },
      };


    tableCheck = {
        init:function  () {
            $(document).on("click",".header.layui-form-checkbox,.x-cate .layui-form-checkbox",function(){
                if($(this).hasClass('layui-form-checked')){
                    $(this).removeClass('layui-form-checked');
                    if($(this).hasClass('header')){
                        $(".layui-form-checkbox").removeClass('layui-form-checked');
                    }
                }else{
                    $(this).addClass('layui-form-checked');
                    if($(this).hasClass('header')){
                        $(".layui-form-checkbox").addClass('layui-form-checked');
                    }
                }
        
            })
        },
        getData:function  () {
            var obj = $(".layui-form-checked").not('.header');
            var arr=[];
            obj.each(function(index, el) {
                arr.push(obj.eq(index).attr('data-id'));
            });
            return arr;
        }
		
    }

    //开启表格多选
    tableCheck.init();
      

    $('.container .left_open i').click(function(event) {
        if($('.left-nav').css('left')=='0px'){
            $('.left-nav').animate({left: '-200px'}, 100);
            $('.page-content').animate({left: '0px'}, 100);
            $('.page-content-bg').hide();
        }else{
            $('.left-nav').animate({left: '0px'}, 100);
            $('.page-content').animate({left: '200px'}, 100);
            if($(window).width()<768){
                $('.page-content-bg').show();
            }
        }

    });

    $('.page-content-bg').click(function(event) {
        $('.left-nav').animate({left: '-221px'}, 100);
        $('.page-content').animate({left: '0px'}, 100);
        $(this).hide();
    });

    $('.layui-tab-close').click(function(event) {
        $('.layui-tab-title li').eq(0).find('i').remove();
    });

   //$("tbody.x-cate tr[fid!='0']").hide();
    // 栏目多级显示效果
    $(document).on("click",".x-show",function(){

        if($(this).attr('status')=='true'){
            $(this).html('&#xe625;');
            $(this).attr('status','false');
            cateId = $(this).parents('tr').attr('cate-id');
            $("tbody tr[fid="+cateId+"]").show();
        }else{
            cateIds = [];
            $(this).html('&#xe623;');
            $(this).attr('status','true');
            cateId = $(this).parents('tr').attr('cate-id');
            getCateId(cateId);
            for (var i in cateIds) {
                $("tbody tr[cate-id="+cateIds[i]+"]").hide().find('.x-show').html('&#xe623;').attr('status','true');
            }
        }
    })

    //左侧菜单效果
    // $('#content').bind("click",function(event){
    $('.left-nav #nav li').click(function (event) {

        if($(this).children('.sub-menu').length){
            if($(this).hasClass('open')){
                $(this).removeClass('open');
                $(this).find('.nav_right').html('&#xe6a7;');
                $(this).children('.sub-menu').stop().slideUp();
                $(this).siblings().children('.sub-menu').slideUp();
            }else{
                $(this).addClass('open');
                $(this).children('a').find('.nav_right').html('&#xe6a6;');
                $(this).children('.sub-menu').stop().slideDown();
                $(this).siblings().children('.sub-menu').stop().slideUp();
                $(this).siblings().find('.nav_right').html('&#xe6a7;');
                $(this).siblings().removeClass('open');
            }
        }else{

            var url = $(this).children('a').attr('_href');
            var title = $(this).find('a').html();
            var index  = $('.left-nav #nav li').index($(this));
            if($(this).parents().hasClass('sub-menu')){
                $("ul.sub-menu li").removeClass('current');
                $(this).addClass('current');
            }
            for (var i = 0; i <$('.x-iframe').length; i++) {
                if($('.x-iframe').eq(i).attr('tab-id')==index+1){
                    tab.tabChange(index+1);
                    event.stopPropagation();
					$('.x-iframe').eq(i).attr("src",$('.x-iframe').eq(i).attr('src'));
                    return;
                }
            };
            
            tab.tabAdd(title,url,index+1);
            tab.tabChange(index+1);
        }
       
        event.stopPropagation();
         CustomRightClick();
         
    })
  
  
   
   $('a.top_nav').click(function (event) {
     	    var url = $(this).attr('x_href');
            var title =$(this).html();
            var left_index  = $('.left-nav #nav li').length;
			var top_index = $('a.top_nav').length;
			var right_index = $('a.top_nav_right').length;
			var own_index = $("dd.top-nav").index($(this).parent())+$(this).parent().parent().parent().index();
			var all_index = left_index+own_index+top_index+right_index;
            for (var i = 0; i <$('.x-iframe').length; i++) {
                if($('.x-iframe').eq(i).attr('tab-id')==(all_index+1)){
                    tab.tabChange(all_index+1);
                    event.stopPropagation();
					$('.x-iframe').eq(i).attr("src",url);
                    return;
                }
            };
            
            tab.tabAdd(title,url,all_index+1);
            tab.tabChange(all_index+1);
     		event.stopPropagation();
            CustomRightClick();
   })
   $('a.top_nav_right').click(function (event) {
     	    var url = $(this).attr('x_href');
            var title =$(this).text();
            var left_index  = $('.left-nav #nav li').length;
			var top_index = $('a.top_nav').length;
			var right_index = $('a.top_nav_right').length;
			var own_index = $(this).index();
			var all_index = left_index+own_index+top_index+right_index;
            for (var i = 0; i <$('.x-iframe').length; i++) {
                if($('.x-iframe').eq(i).attr('tab-id')==(all_index+2)){
                    tab.tabChange(all_index+2);
                    event.stopPropagation();
					$('.x-iframe').eq(i).attr("src",url);
                    return;
                }
            };
            
            tab.tabAdd(title,url,all_index+2);
            tab.tabChange(all_index+2);
     		event.stopPropagation();
            CustomRightClick();
   })

  

    $(".rightmenu li").click(function () {
       
        if ($(this).attr("data-type") == "closethis") {
            var tabid = $(".layui-tab-title li.layui-this").attr('lay-id');// 获取当前激活的选项卡ID
            tab.tabDelete(tabid);
        } else if ($(this).attr("data-type") == "closeall") {
            tab.closeall();
        }else{
          
            tab.closeother();
        }
        $('.rightmenu').hide();
    })
    
})
var cateIds = [];
function getCateId(cateId) {
    
    $("tbody tr[fid="+cateId+"]").each(function(index, el) {
        id = $(el).attr('cate-id');
        cateIds.push(id);
        getCateId(id);
    });
}

/*弹出层*/
/*
    参数解释：
    title   标题
    url     请求的url
    id      需要操作的数据id
    w       弹出层宽度（缺省调默认值）
    h       弹出层高度（缺省调默认值）
*/
function x_all_show(title,url,w,h){
    if (title == null || title == '') {
        title=false;
    };
    if (url == null || url == '') {
        url="404.html";
    };
    if (w == null || w == '') {
        w=($(window).width()*0.9);
    };
    if (h == null || h == '') {
        h=($(window).height() - 50);
    };
	//window.location.href=url;return false;
    layer.open({
        type: 2,
        area: [w+'px', h +'px'],
        fix: false, //不固定
        maxmin: true,
        shadeClose: false,
        shade:0.4,
        title: title,
        content: url
    });
	
}

/*关闭弹出框口*/
function x_admin_close(){
    var index = parent.layer.getFrameIndex(window.name);
    parent.layer.close(index);
}


/**
* 注册tab右键菜单点击事件
*/


// 点击空白处关闭右键弹窗
$(document).click(function () {
    $('.rightmenu').hide();
})

/**
* 绑定右键菜单
* @constructor
*/
function CustomRightClick () {

    //屏蔽右键
    $('.layui-tab-title li').on('contextmenu', function () {
        return false;
    })
    $('.layui-tab-title,.layui-tab-title li').click(function () {
        $('.rightmenu').hide();
    });
    $('.layui-tab-title li').on('contextmenu', function (e) {
        var popupmenu = $(".rightmenu");
        l = ($(document).width() - e.clientX) < popupmenu.width() ? (e.clientX - popupmenu.width()) : e.clientX;
        t = ($(document).height() - e.clientY) < popupmenu.height() ? (e.clientY - popupmenu.height()) : e.clientY;
        popupmenu.css({left: l, top: t}).show();
        return false;
    });
}

