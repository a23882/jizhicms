<?php if (!defined('CORE_PATH')) exit();?><!DOCTYPE html>
<html class="no-js" lang="cn">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $webconf['web_name'] ?></title>
	<meta name="keywords" content="<?php echo $webconf['web_keyword'] ?>" />
	<meta name="description" content="<?php echo $webconf['web_desc'] ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
	<link rel="stylesheet" href="<?php echo $tpl ?>static/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $tpl ?>static/css/gordita-fonts.css" />
    <link rel="stylesheet" href="<?php echo $tpl ?>static/css/vendor.min.css" />
    <link rel="stylesheet" href="<?php echo $tpl ?>static/css/plugins.min.css" />
    <link rel="stylesheet" href="<?php echo $tpl ?>static/css/animate.min.css" />
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo $tpl ?>static/css/style.css?v=1" />
    <link rel="stylesheet" href="<?php echo $common ?>/layui/css/layui.css" />
  </head>
  <body class="theme-color-two">
   
    <header class="header-two <?php if($ishome){ ?>position--absolute<?php }else{ ?>position--relative<?php } ?>">
      <div class="header-bottom-area">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-2 col-md-3 col-5">
              <div class="logo">
                <a href="/"><img src="<?php echo $webconf['web_logo'] ?>" alt="<?php echo $webconf['web_name'] ?>" /></a>
              </div>
            </div>
            <div class="col-lg-8 d-lg-block d-none">
              <div class="main-menu-area text-center">
                <nav class="navigation-menu navigation-menu-white">
                  <ul>
					<li>
						  <a href="/"><span>首页</span></a>
					</li>
				    <?php $v_n=0;foreach( $classtypedata as $v){ $v_n++;?>
					<?php if($v['pid']==0 && $v['isshow']==1){ ?>
						<?php if($v['haschild']){ ?>
						<li class="has-children">
						  <a href="<?php echo $v['url'] ?>"><span><?php echo $v['classname'] ?></span></a>
						  <ul class="submenu">
						    <?php $vv_n=0;foreach( $v['children']['list'] as $vv){ $vv_n++;?>
							<li>
							  <a href="<?php echo $vv['url'] ?>"><span><?php echo $vv['classname'] ?></span></a>
							</li>
							<?php } ?>
							
						  </ul>
						</li>
						<?php }else{ ?>
						<li>
						  <a href="<?php echo $v['url'] ?>"><span><?php echo $v['classname'] ?></span></a>
						</li>
						
						<?php } ?>
					<?php } ?>
				    <?php } ?>
                   
                    
                  </ul>
                </nav>
              </div>
            </div>
            <div class="col-lg-2 col-md-9 col-7">
              <div class="header-two-right-side">
                <a href="/user/notify" class="single-action-item">
                  <span id="notifiy-icon" class=""></span>
                  <img src="<?php echo $tpl ?>static/picture/notification-white.png" alt="" />
                </a>
				<?php if($islogin){ ?>
                <a href="/user/index" class="single-action-item">
                  <img src="<?php echo $tpl ?>static/picture/user-white.png" alt="" />
                </a>
				<?php }else{ ?>
				<a data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#loginModel" class="single-action-item">
                  <img src="<?php echo $tpl ?>static/picture/user-white.png" alt="" />
                </a>
				<?php } ?>
                <!-- mobile menu -->
                <div
                  class="mobile-navigation-icon icon-white d-block d-lg-none"
                  id="mobile-menu-trigger"
                >
                  <i></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    

    <div id="main-wrapper">
      <div class="site-wrapper-reveal">
		<div class="hero-area-two-wrapper">
                <!-- Hero Area Start -->
                <div class="hero-area-two hero-area-overly">
                    <div class="container">
                        <div class="col-lg-12">
                            <div class="hero-area--two-innter text-center">
                       
								<h1 class="hero-title">极致建站系统</h1>
								<h2><span class="hero-title-small">建站、教程、资源</span></h2>
								<div class="hero-two-tag">
									<a  class="btn-outline-2 btn-large">免费</a>
									<a  class="btn-outline-2 btn-large">开源</a>
									<a  class="btn-outline-2 btn-large">无商业授权</a>
									<a  class="btn-outline-2 btn-large">功能强大</a>
									<a  class="btn-outline-2 btn-large">简单易用</a>
									<a  class="btn-outline-2 btn-large">无限制</a>
									<a  class="btn-outline-2 btn-large">安全可靠</a>
								</div>
                            </div>
                        </div>
                    </div>
                </div><!-- Hero Area End -->

                <div class="hero-two-banner-text">
                    
                </div>
        </div>
<!-- Most Popular Area Start -->
        <div class="most-populer-area section-space--ptb_120">
          <div class="container">
            <div class="row">
              <div class="col-8">
                <div class="section-title">
                  <h2>热门模板</h2>
                </div>
              </div>
              <div class="col-4">
                <div class="most-popular-slider-navigation">
                  <div class="popular-swiper-button-prev navigation-button">
                    <i class="icofont-long-arrow-left"></i>
                  </div>
                  <div class="popular-swiper-button-next navigation-button">
                    <i class="icofont-long-arrow-right"></i>
                  </div>
                </div>
              </div>
            </div>
            <!-- Swiper -->
            <div class="swiper-container most-popular-slider-active">
              <div class="swiper-wrapper">
			   <?php
		$v_table ='product';
		
		$v_w=' 1=1 and isshow=\'1\'  and (  jzattr like \'%,1,%\'  or jzattr like \'%,2,%\'  or jzattr like \'%,3,%\'   )  and (trim(litpic) !="" && trim(litpic) is not null)   and addtime<=1766473695 ';
		$v_order='orders desc';
		$v_fields=null;
		$v_prefix = 1;
		$v_limit='6';
				$v_data = M($v_table,$v_prefix)->findAll($v_w,$v_order,$v_fields,$v_limit);$v_n=0;foreach($v_data as $v_key=> $v){
			$v_n++;
			if(!array_key_exists('url',$v)){
				
				if($v_table=='classtype'){
					$v['url'] = $classtypedata[$v['id']]['url'];
				}else if($v_table=='message'){
					$v['url'] = U('message/details',['id'=>$v['id']]);
				}else if($v_table=='tags'){
					$v['url'] = U('tags/index',['id'=>$v['id']]);
				}else{
					$v['url'] = gourl($v,$v['htmlurl']);
				}
				
			}
			?>
                <div class="swiper-slide">
                  
                  <div class="single-most-populer-item wow fadeInUp" >
                    <a href="<?php echo $v['url'] ?>" class="most-populer-thum">
                      <img src="<?php echo $v['litpic'] ?>" alt="<?php echo $v['title'] ?>" />
                    </a>
                    <div class="most-populer-content">
                      <div class="most-populer-post-author">
						  <?php if(!$v['member_id']){ ?>
                            作者 <a href="<?php echo $v['url'] ?>"><?php echo adminInfo($v['userid'],'name') ?></a>
						  <?php }else{ ?>
						    作者 <a href="/user/active/uid/<?php echo $v['member_id'] ?>"><?php echo memberInfo($v['member_id'],'username') ?></a>
						  <?php } ?>
                      </div>
                      <h3 class="title">
                        <a href="<?php echo $v['url'] ?>"
                          ><?php echo $v['title'] ?></a
                        >
                      </h3>
					  <p class="dec mt-2">
                      <span class="product-price">￥ <?php echo $v['price'] ?></span>
                      </p>
                      <div class="most-populer-post-meta">
                        <span class="post-date">
                          <a><?php echo date('Y-m-d',$v['addtime']) ?></a>
                        </span>
                        <span>热度 <?php echo $v['hits'] ?></span>
                      </div>
                    </div>
                  </div>
       
                </div>
			    <?php } ?>

               
			  </div>
            </div>
          </div>
        </div>
        <!-- Most Popular Area End -->

	    
        <!-- Recent Article Area Start -->
        <div class="recent-article-area section-space--pb_120">
          <div class="container">
            <div class="row">
              <div class="col-lg-12">
                <div class="section-title text-center section-border-bottom">
                  <h2>最近更新</h2>
                </div>
              </div>
            </div>
            <div class="row row--30">
			<?php
		$v_table ='article';
		
		$v_w=' 1=1 and isshow=\'1\'  and (trim(litpic) !="" && trim(litpic) is not null)   and addtime<=1766473695 ';
		$v_order='addtime desc';
		$v_fields=null;
		$v_prefix = 1;
		$v_limit='6';
				$v_data = M($v_table,$v_prefix)->findAll($v_w,$v_order,$v_fields,$v_limit);$v_n=0;foreach($v_data as $v_key=> $v){
			$v_n++;
			if(!array_key_exists('url',$v)){
				
				if($v_table=='classtype'){
					$v['url'] = $classtypedata[$v['id']]['url'];
				}else if($v_table=='message'){
					$v['url'] = U('message/details',['id'=>$v['id']]);
				}else if($v_table=='tags'){
					$v['url'] = U('tags/index',['id'=>$v['id']]);
				}else{
					$v['url'] = gourl($v,$v['htmlurl']);
				}
				
			}
			?>
              <div class="col-lg-4 col-md-6">
                
                <div class="single-most-populer-item wow fadeInUp" >
                  <a href="<?php echo $v['url'] ?>" class="most-populer-thum">
                    <img src="<?php echo $v['litpic'] ?>" alt="<?php echo $v['title'] ?>" />
                  </a>
                  <div class="most-populer-content">
                    <div class="most-populer-post-author">
                       作者 <a href="<?php echo $v['url'] ?>"><?php echo adminInfo($v['userid'],'name') ?></a>
                    </div>
                    <h3 class="title">
                      <a href="<?php echo $v['url'] ?>"
                        ><?php echo $v['title'] ?></a
                      >
                    </h3>
                    <p class="dec mt-2">
                      <?php echo newstr($v['description'],80) ?>
                    </p>
                    <div class="most-populer-post-meta">
                      <span class="post-date">
                        <a><?php echo date('Y-m-d',$v['addtime']) ?></a>
                      </span>
                      <span>阅 <?php echo $v['hits'] ?></span>
                    </div>
                  </div>
                </div>
               
              </div>
			<?php } ?>
             
             
			</div>
          </div>
        </div>
        <!-- Recent Article Area End -->
				  <!-- Related Newsletter Area Start -->
        <div class="related-newsletter-area">
          <div class="container">
            <div class="row">
              <div class="col-lg-12">
                <div class="related-newsletter-box">
                  <div class="related-newsletter-inner-box">
                    <h2 class="title">
                      国内企业用户 <b style="color:#F00">200+</b> 家
                     
                    </h2>
					<h2 class="title"> 下载使用超 <b style="color:#F00">100000+</b> 人</h2>
                    <div class="button-box mt-30">
                      <a
                        href="https://www.jizhicms.cn/jizhicms.zip"
                        class="btn-primary btn-bg-2 bg-color btn-large"
                        >立即下载使用</a
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Related Newsletter Area End -->
        
       <div class="testimonial-area bg-gray section-space--ptb_120">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title text-center mb-10" >
                                <h6 class="sub-title-four mb-20">用户评价</h6>
                                <h2 class="title">人们对我们的评价</h2>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-slider-area">
                        <div class="swiper-container testimonial-slider-active">
                            <div class="swiper-wrapper">
							<?php
		$v_table ='pingjia';
		
		$v_w=' 1=1 and isshow=\'1\' ';
		$v_order='orders desc';
		$v_fields=null;
		$v_prefix = 1;
		$v_limit=null;
				$v_data = M($v_table,$v_prefix)->findAll($v_w,$v_order,$v_fields,$v_limit);$v_n=0;foreach($v_data as $v_key=> $v){
			$v_n++;
			if(!array_key_exists('url',$v)){
				
				if($v_table=='classtype'){
					$v['url'] = $classtypedata[$v['id']]['url'];
				}else if($v_table=='message'){
					$v['url'] = U('message/details',['id'=>$v['id']]);
				}else if($v_table=='tags'){
					$v['url'] = U('tags/index',['id'=>$v['id']]);
				}else{
					$v['url'] = gourl($v,$v['htmlurl']);
				}
				
			}
			?>
                                <div class="swiper-slide">
                                    <div class="single-testimonial-item wow fadeInUp" >
                                        <div class="testimonial-post-author">
                                            <div class="testimonial-author-image">
                                                <img src="<?php echo $v['litpic'] ?>" alt="<?php echo $v['title'] ?>">
                                            </div>
                                            <div class="testimonial-author-info">
                                                <h4><?php echo $v['title'] ?></h4>
                                                <p><?php echo $v['zhiye'] ?></p>
                                            </div>
                                        </div>
                                        <div class="testimonial-post-content">
                                            <h5 class="testimonial-post-title"><?php echo $v['description'] ?></h5>
                                            <p><?php echo $v['body'] ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
							<?php } ?>
                                
                            </div>
                        </div>
                        <div class="testimonial-slider-navigation">
                            <div class="testimonial-button-next navigation-button"><i class="icofont-long-arrow-left"></i></div>
                            <div class="testimonial-button-prev navigation-button"><i class="icofont-long-arrow-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
            
	   
	   
      </div>
    </div>

      <!--======  footer area =======-->
    <footer class="footer-area footer-two">
      <div class="footer-top-area">
        <div class="container-fluid container-custom-xl">
          <div class="row">
            <div class="col-lg-4 col-md-8 col-sm-8 order-lg-1 order-1">
              <div class="footer-widget">
                <div class="footer-logo">
                  <a href="/">
                    <img src="<?php echo $webconf['web_logo'] ?>" alt="<?php echo $webconf['web_name'] ?>" />
                  </a>
                </div>
                <p>
                  <?php echo $webconf['web_desc'] ?>
                </p>
                
               
              </div>
            </div>
            <div class="col-lg-8 order-lg-2 order-3">
              <div class="footer-menu-widget">
			    <?php $v_n=0;foreach( $classtypedata as $v){ $v_n++;?>
			    <?php if($v['pid']==0 && $v['isshow']==1 && $v['haschild']){ ?>
					
					<div class="single-footer-menu">
					  <div class="footer-widget-title">
						<h4 class="title"><?php echo $v['classname'] ?></h4>
					  </div>
					  
					  <ul class="footer-widget-menu-list">
					    <?php $vv_n=0;foreach( $v['children']['list'] as $vv){ $vv_n++;?>
						<li><a href="<?php echo $vv['url'] ?>"><?php echo $vv['classname'] ?></a></li>
						<?php } ?>
						
					  </ul>
					  
					</div>
					
				<?php } ?>
				<?php } ?>
               
				</div>
            </div>
           
		  </div>
        </div>
      </div>
      <div class="footer-bottom-area">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12">
              <div class="copy-right-center">
                <p>
                  © <?php echo date('Y') ?> powered by <?php echo $webconf['web_name'] ?> <a href="https://beian.miit.gov.cn/" target="_blank" ><?php echo $webconf['web_beian'] ?></a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <a
      href="#"
      class="scroll-top"
      id="scroll-top"
      ><i class="arrow-top icofont-swoosh-up"></i
      ><i class="arrow-bottom icofont-swoosh-up"></i></a
    >
    <div class="mobile-menu-overlay" id="mobile-menu-overlay">
      <div class="mobile-menu-overlay__inner">
        <div class="mobile-menu-overlay__header">
          <div class="container-fluid">
            <div class="row align-items-center">
              <div class="col-md-6 col-8">
                <!-- logo -->
                <div class="logo">
                  <a href="/"
                    ><img
                      src="<?php echo $webconf['web_logo'] ?>"
                      class="img-fluid"
                      alt=""
                  /></a>
                </div>
              </div>
              <div class="col-md-6 col-4">
                <!-- mobile menu content -->
                <div class="mobile-menu-content text-end">
                  <span
                    class="mobile-navigation-close-icon"
                    id="mobile-menu-close-trigger"
                  ></span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="mobile-menu-overlay__body">
          <nav class="offcanvas-navigation">
		 
            <ul>
			 <?php $v_n=0;foreach( $classtypedata as $v){ $v_n++;?>
			 <?php if($v['pid']==0 && $v['isshow']==1){ ?>
				 <?php if($v['haschild']){ ?>
				<li class="has-children">
				  <a href="<?php echo $v['url'] ?>"><span><?php echo $v['classname'] ?></span></a>
				  <ul class="sub-menu">
					<?php $vv_n=0;foreach( $v['children']['list'] as $vv){ $vv_n++;?>
					<li>
					  <a href="<?php echo $vv['url'] ?>"><span><?php echo $vv['classname'] ?></span></a>
					</li>
					<?php } ?>
					
				  </ul>
				</li>
				<?php }else{ ?>
				<li>
				  <a href="<?php echo $v['url'] ?>"><span><?php echo $v['classname'] ?></span></a>
				</li>
				
				<?php } ?>
              
			  <?php } ?>
			  <?php } ?>
             
            </ul>
          </nav>
        </div>
      </div>
    </div>
<!-- Modal -->
<div class="modal fade" id="loginModel" tabindex="-1" aria-labelledby="loginModelLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="loginModelLabel">登录</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       
	    <div class="mb-3">
		  <label for="m-user" class="form-label">账户</label>
		  <input type="text" class="form-control" id="m-user" placeholder="请输入邮箱/昵称/手机号">
		</div>
		<div class="mb-3">
		  <label for="m-pass" class="form-label">密码</label>
		  <input type="password" class="form-control" id="m-pass" placeholder="请输入登录密码">
		</div>
		<?php if(!$webconf['closehomevercode']){ ?>
		<div class="mb-3">
		  <label for="m-yzm" class="form-label">验证码</label>
		  <input type="text" class="form-control" id="m-yzm" placeholder="请输入验证码">
		</div>
		<div class="mb-3">
			<img id="login-yzm" src="/common/vercode?name=login_vercode"  onclick="this.src=this.src+'&'+Math.random()">
		</div>
		<?php } ?>
		<div class="mb-3">
		<p>没有账户？<a  class="register" style="color:#5974ff;" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#registerModel">点击注册</a></p>
		</div>
		
		
		
	   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
        <button type="button" onclick="mlogin()" class="btn btn-primary">登录</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="registerModel" tabindex="-1" aria-labelledby="registerModelLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="registerModelLabel">注册</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
		  <label for="r-tel" class="form-label">*手机</label>
		  <input type="tel" class="form-control" id="r-tel" placeholder="请输入手机号">
		</div>
		<div class="mb-3">
		  <label for="r-pass" class="form-label">*密码</label>
		  <input type="password" class="form-control" id="r-pass" placeholder="请输入登录密码">
		</div>
		<div class="mb-3">
		  <label for="r-pass" class="form-label">*重复密码</label>
		  <input type="password" class="form-control" id="r-repass" placeholder="请输入登录密码">
		</div>
		<?php if(!$webconf['closehomevercode']){ ?>
		<div class="mb-3">
		  <label for="r-yzm" class="form-label">*验证码</label>
		  <input type="text" class="form-control" id="r-yzm" placeholder="请输入验证码">
		</div>		
		<div class="mb-3">
			<img id="register-yzm" src="/common/vercode?name=reg_vercode" onclick="this.src=this.src+'&'+Math.random()">
		</div>
		<?php } ?>
		<div class="mb-3">
		<p>已有账户？<a  class="login" style="color:#5974ff;" data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#loginModel">点击登录</a></p>
		</div>
		
		
		
	   
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
        <button type="button" onclick="mregister()" class="btn btn-primary">注册</button>
      </div>
    </div>
  </div>
</div>





    <script src="<?php echo $tpl ?>static/js/vendor.min.js"></script>
<script src="<?php echo $tpl ?>static/js/plugins.min.js"></script>
<script src="<?php echo $tpl ?>static/js/smoothproducts.min.js"></script>
<script src="<?php echo $tpl ?>static/js/wow.min.js"></script>
<!-- Main JS -->
<script src="<?php echo $tpl ?>static/js/main.js"></script>
<script src="<?php echo $common ?>layui/layui.js"></script>
<script src="/static/common/md5.js" charset="utf-8"></script>
<script>
function likes(tid,id){
        $.ajax({
                 url:"/user/likesAction",//请求的url地址
                 dataType:"json",//返回格式为json
                 async:true,//请求是否异步，默认为异步，这也是ajax重要特性
                 data:{tid:tid,id:id,ajax:1},//参数值
                 type:"POST",//请求方式
                 beforeSend:function(){
                    //请求前的处理
                    },
				 success:function(r){
					if(r.code==0){
						layer.msg(r.msg,{icon: 6,time: 2000},function(){
							location.reload();
						});
					   
					}else{
						layer.alert(r.msg);
					}

				},
				 complete:function(){
				//请求完成的处理
				},
				 error:function(){
				//请求出错处理
					layer.alert('网络错误');
				}



            })
    }

function collect(tid,id){
        $.ajax({
                 url:"/user/collectAction",//请求的url地址
                 dataType:"json",//返回格式为json
                 async:true,//请求是否异步，默认为异步，这也是ajax重要特性
                 data:{tid:tid,id:id,ajax:1},//参数值
                 type:"POST",//请求方式
                 beforeSend:function(){
                    //请求前的处理
                    },
				 success:function(r){
					if(r.code==0){
						layer.msg(r.msg,{icon: 6,time: 2000},function(){
							location.reload();
						});
					}else{
						layer.alert(r.msg);
					}

				},
				 complete:function(){
				//请求完成的处理
				},
				 error:function(){
				//请求出错处理
					layer.alert('网络错误');
				}



            })
    }

function mlogin(){
	var user = $("#m-user").val();
	var pass = $("#m-pass").val();
	
	if(user==''){
		layer.alert('登录账户不能为空！');return false;
	}
	if(pass==''){
		layer.alert('登录密码不能为空！');return false;
	}
	<?php if(!$webconf['closehomevercode']){ ?>
	var yzm = $("#m-yzm").val();
	if(yzm==''){
		layer.alert('验证码不能为空！');return false;
	}
	<?php }else{ ?>
	var yzm = '';
	<?php } ?>
		pass = hex_md5(pass)
	$.post('/login/index',{tel:user,password:pass,vercode:yzm,ajax:1},function(res){
		if(res.code==0){
			layer.msg('登录成功！',{icon: 6,time: 2000},function(){
				//登录成功后的操作
				location.reload();
			})
		}else{
			layer.msg(res.msg,{icon:5,time:2000});
			var img = '/common/vercode?name=login_vercode&'+Math.random();
			$("#login-yzm").attr('src',img);
		}
	},'json')
	
	return false;
	
}

function mregister(){
	var tel = $("#r-tel").val();
	var pass = $("#r-pass").val();
	var repass = $("#r-repass").val();
	
	if(tel==''){
		layer.alert('手机号不能为空！');return false;
	}
	if(pass==''){
		layer.alert('登录密码不能为空！');return false;
	}
	if(repass==''){
		layer.alert('重复密码不能为空！');return false;
	}
	if(pass!=repass){
		layer.alert('两次密码不同！');return false;
	}
	<?php if(!$webconf['closehomevercode']){ ?>
	var yzm = $("#r-yzm").val();
	if(yzm==''){
		layer.alert('验证码不能为空！');return false;
	}
	<?php }else{ ?>
	var yzm = '';
	<?php } ?>
	
	$.post('/login/register',{tel:tel,repassword:repass,password:pass,vercode:yzm,ajax:1,autologin:1},function(res){
		if(res.code==0){
			layer.msg(res.msg,{icon: 6,time: 2000},function(){
				//登录成功后的操作
				window.location.href=res.url;
			})
		}else{
			layer.msg(res.msg,{icon:5,time:2000});
			var img = '/common/vercode?name=reg_vercode&'+Math.random();
			$("#register-yzm").attr('src',img);
		}
	},'json')
	
	return false;
	
}

function sendmsg(){
	var star = $("#star").val();
	var tid = $("#tid").val();
	var aid = $("#aid").val();
	var zid = $("#zid").val();
	var pid = $("#pid").val();
	var content = $("#content").val();
	if(content==''){
		layer.alert('评论内容不能为空！');
		return false;
	}
	$.post('/comment/index',{star:star,tid:tid,aid:aid,zid:zid,pid:pid,body:content,ajax:1,go:1},function(res){
		if(res.code==0){
			layer.msg(res.msg,{icon:6,time:2000},function(){
				location.reload();
			})
		}else{
			layer.msg(res.msg,{icon:5,time:2000})
		}
	},'json');
	
	return false;
	
	
}

function reply(pid,username,zid){
	$("#zid").val(zid);
	$("#pid").val(pid);
	$("#content").val('[@'+username+']');
	$("#content").focus();
}

var page; 
if(undefined == page){ 
  page = 1;
} 

function getmessagelist(tid,aid,page){
	$.ajax({
		 url:"/comment/getlist",
		 dataType:"json",
		 data:{tid:tid,aid:aid,page:page,limit:10},
		 async:true,
		 type:"GET",
		 success:function(r){
			if(r.code==0){
				var len = r.data.list.length;
				var html = '';
				if(len>0){
					for(var i=0;i<len;i++){
						var rdata = r.data.list[i];
						html+='<li class="comment">'+
							  '<div class="comment-2">'+
								'<div class="comment-author-info">'+
								  '<div class="comment-author vcard">'+
									'<img alt="'+rdata.user.username+'" src="'+rdata.user.litpic+'" onerror="this.src=\'<?php echo $tpl ?>static/picture/comments-3.png\'" />'+
								  '</div>'+
								  '<div class="comment-content">'+
									'<div class="meta">'+
									  '<div class="comment-content-top">'+
										'<div class="comment-actions">'+
										  '<h6 class="fn">'+rdata.user.username+'</h6>'+
										  '<span class="time">'+rdata.addtime+'</span>'+
										'</div>'+
									  '</div>'+
									  '<a class="comment-reply-link" onclick="reply('+rdata.id+',\''+rdata.user.username+'\','+rdata.id+')"><i class="icofont-reply"></i> 回复</a>'+
									'</div>'+
								  '</div>'+
								'</div>'+
								'<div class="comment-text">'+
								  '<p>'+rdata.body+
								  '</p>'+
								'</div>'+
							  '</div>';
						var llen = rdata.children.length;
						if(llen>0){
							html+='<ol class="children">';
							for(var j=0;j<llen;j++){
								var rrdata = rdata.children[j];
								html+='<li class="comment">'+
							  '<div class="comment-2">'+
								'<div class="comment-author-info">'+
								  '<div class="comment-author vcard">'+
									'<img alt="'+rrdata.user.username+'" src="'+rrdata.user.litpic+'" onerror="this.src=\'<?php echo $tpl ?>static/picture/comments-3.png\'" />'+
								  '</div>'+
								  '<div class="comment-content">'+
									'<div class="meta">'+
									  '<div class="comment-content-top">'+
										'<div class="comment-actions">'+
										  '<h6 class="fn">'+rrdata.user.username+'</h6>'+
										  '<span class="time">'+rrdata.addtime+'</span>'+
										'</div>'+
									  '</div>'+
									  '<a class="comment-reply-link" onclick="reply('+rrdata.id+',\''+rrdata.user.username+'\','+rdata.id+')"><i class="icofont-reply"></i> 回复</a>'+
									'</div>'+
								  '</div>'+
								'</div>'+
								'<div class="comment-text">'+
								  '<p>'+rrdata.body+
								  '</p>'+
								'</div>'+
							  '</div>';
							}
							html+='</ol>';
						}
						html+='</li>';
					}
	
					$("#jz_comment_list").html(html);
				}else{
					var page = r.data.allpage;
					//layer.msg('没有了',{icon:6,time:1000});
				}
				
				$("#jz_comment_num").html(r.data.count);
				var allpage = parseInt(r.data.allpage);
				if(allpage>1){
					$(".comment-page-bar").show();
				}else{
					$(".comment-page-bar").hide();
				}
				
			}
		 }
	})
}

function nextmessagelist(){
	page++;
	var tid = $("#tid").val();
	var aid = $("#aid").val();
	getmessagelist(tid,aid,page)
}

function prevmessagelist(){
	page = page-1;
	page = page<0 ? 1 : page;
	var tid = $("#tid").val();
	var aid = $("#aid").val();
	getmessagelist(tid,aid,page)
}

function addcart(tid,id,num){
	$.ajax({
		 url:"/user/addcart",//请求的url地址
		 dataType:"json",//返回格式为json
		 async:true,//请求是否异步，默认为异步，这也是ajax重要特性
		 data:{tid:tid,id:id,num:num,ajax:1},//参数值
		 type:"POST",//请求方式
		 beforeSend:function(){
			//请求前的处理
			},
			 success:function(r){
				if(r.code==0){
					window.location.href=r.url;
				}else{
					layer.alert(r.msg);
				}

			},
			 complete:function(){
			//请求完成的处理
			},
			 error:function(){
			//请求出错处理
				layer.alert('网络错误');
			}



	})
}
$(function(){
	
	var interval =  setInterval(function(){
	$.ajax({
		 url:"/common/updateactive",
		 dataType:"json",
		 async:true,
		 type:"GET",
		 success:function(r){
		 }
	})
	},30000);
	var interval2 =  setInterval(function(){
	$.ajax({
		 url:"/user/getmsg",
		 async:true,
		 type:"GET",
		 success:function(r){
			var n = parseInt(r);
			if(n>0){
			$("#notifiy-icon").addClass('new-notification')
			}else{
			$("#notifiy-icon").removeClass('new-notification')
			}
			$("#notifiy-num").html(n);
			
		 }
	})
	},30000);


 })



</script>
  </body>
</html>
