<?php if (!defined('CORE_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="UTF-8">
		<title><?php echo webConf('web_name') ?></title>
	<meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta http-equiv="Cache-Control" content="no-siteapp" />
	<meta name="author" content="留恋风,2581047041@qq.com"> 
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="<?php echo Tpl_style ?>/style/fonts/iconfont.css?v=1">
	<link rel="stylesheet" href="<?php echo Tpl_style ?>/style/css/xadmin.css?v=3">
	<link rel="stylesheet" href="<?php echo Tpl_style ?>/style/css/style.css?v=1">
    <script type="text/javascript" src="<?php echo Tpl_style ?>/style/js/jquery.min.js"></script>
    <script src="/static/common/layui/layui.js?v=2.6.8" charset="utf-8"></script>
	<script type="text/javascript" src="<?php echo Tpl_style ?>/style/js/xadmin.js?v=2.1"></script>
	<script type="text/javascript" src="/static/common/clipboard.js"></script>
	<script type="text/javascript" charset="utf-8" src="<?php echo Tpl_style ?>/style/js/xm-select.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo Tpl_style ?>/style/tags/jquery.tagsinput.css" />
	<script type="text/javascript" charset="utf-8" src="<?php echo Tpl_style ?>/style/tags/jquery.tagsinput.js"></script>
	<?php  
	
	switch($webconf['admintpl']){
		case 'tpl':
		echo '<script type="text/javascript" src="'.Tpl_style.'/style/js/target_page.js"></script>';
		break;
		case 'default':
		echo '<script type="text/javascript" src="'.Tpl_style.'/style/js/target_window.js"></script>';
		break;
	}
	
	
	 ?>
	<style>
	.layui-form-item .layui-input-inline {
		float: left;
		width: 250px;
		margin-right: 10px;
	}
	</style>

	<script src="/static/common/md5.js" charset="utf-8"></script>
</head>
<body class="login-bg">
    
    <div class="login layui-anim layui-anim-up">
        <div class="message"><?php echo JZLANG('后台管理登录') ?></div>
        <div id="darkbannerwrap"></div>
        
        <form method="post" class="layui-form" onsubmit="return false;"  >
            <input name="cache" id="cache" type="hidden" value="" />
			<select name="lang"  lay-filter="lang">
				<option value="">选择语言</option>
				<option <?php if(LANG=='zh'){ ?> selected <?php } ?> value="zh">中文简体</option>
				<option <?php if(LANG=='cht'){ ?> selected <?php } ?> value="cht">中文繁体</option>
				<option <?php if(LANG=='en'){ ?> selected <?php } ?> value="en">English</option>

			</select>
			<hr class="hr15">
            <input name="username" placeholder="<?php echo JZLANG('用户名') ?>"  type="text" lay-verify="required" class="layui-input" >
            <hr class="hr15">
            <input name="password" lay-verify="required" placeholder="<?php echo JZLANG('密码') ?>"  type="password" class="layui-input">
            <hr class="hr15">
			<?php if($webconf['closeadminvercode']!=1){ ?>
			<input name="vercode" style="width:50%;float:left;" lay-verify="required" placeholder="<?php echo JZLANG('验证码') ?>"  type="text" class="layui-input">
			<img id="vercodeimg"  src="<?php echo U('vercode') ?>" style="width:40%;float:right;" onclick="this.src=this.src+'?'+Math.random()" />
            <hr class="hr15">
			<?php } ?>
            <input value="<?php echo JZLANG('登录') ?>" lay-submit lay-filter="login" style="width:100%;" type="submit">
            <hr class="hr20" >
        </form>
    </div>

    <script>
        $(function  () {
			if (top.location != self.location){
			top.location = self.location;
			}
				
			$("#cache").val(Math.random());
		
			
            layui.use('form', function(){
              var form = layui.form;
				form.on('select(lang)', function(data){
					var url = window.location.href;
					var url_ = url.split('?');
					var aurl = url_[0];
					if(data.value!=''){
						window.location.href=aurl+'?l='+data.value;
					}
				});
              //监听提交
              form.on('submit(login)', function(data){
           		data.field.password = hex_md5(data.field.password)
				$.post("<?php echo U('Login/index') ?>",data.field,function(res){
				    
					 var res = JSON.parse(res);
					 if(res.code==1){
						var src = '<?php echo U('vercode') ?>?'+Math.random();
						$("#vercodeimg").attr('src',src);
						layer.msg(res.msg);
					 }else{
						layer.msg(res.msg, {icon: 6,time: 2000},function(){
						window.location.href="<?php echo U('Index/index') ?>";
						});
                     
						
						 
					 }
				})
				
                return false;
              });
            });
        })

        
    </script>

    
 
</body>
</html>